// var toastGroupTemplate = document.querySelector('#toastGroup');
// toastGroupTemplate.showToast = function() {
//   document.querySelector('#toast').show();
// }
